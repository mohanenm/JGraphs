/**
 * The front-end API's interfaces and classes, including {@link org.jgrapht.Graph}.
 */
package org.jgrapht;
